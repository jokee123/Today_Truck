package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TBSException;
import com.capgemini.truckbooking.utility.JdbcUtility;

public class ITruckDaoImpl implements ITruckDao {
	Connection connection = null;
	PreparedStatement statement = null;
	int result = 0;
	static Logger logger = Logger.getLogger(ITruckDaoImpl.class);
	ResultSet resultSet = null;

	@Override
	public List<TruckBean> truckAvailability(Integer truckID) throws TBSException {
		connection = JdbcUtility.getConnection();

		logger.info("connection created");
		List<TruckBean> list = null;

		try {
			statement = connection.prepareStatement(QueryMapper.setDetails);

			statement.setInt(1, truckID);
			resultSet = statement.executeQuery();

			resultSet.next();
			Integer id = resultSet.getInt(1);
			String type = resultSet.getString(2);
			String origin = resultSet.getString(3);
			String destination = resultSet.getString(4);
			Float charge = resultSet.getFloat(5);
			Integer available = resultSet.getInt(6);
			System.out.println(available);
			TruckBean truckBean = new TruckBean();
			truckBean.setTruckID(id);
			truckBean.setTruckType(type);
			truckBean.setOrigin(origin);
			truckBean.setDestination(destination);
			truckBean.setCharges(charge);
			truckBean.setAvailableNos(available);
			list = new ArrayList<>();
			list.add(truckBean);
			// System.out.println(available);

		} catch (SQLException e) {
			System.out.println("haii");
			e.printStackTrace();
		} finally {
			try {
				statement.close();
				/* logger.info("statement closed"); */
			} catch (SQLException e) {
				System.err.println("statement not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection not created");
			}

		}

		return list;
	}

	@Override
	public int bookDetails(BookingBean bookingBean) throws TBSException {
		connection = JdbcUtility.getConnection();
		int bookId = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.getDetails);
			// statement.setInt(1, bookingBean.getBookingID());
			resultSet = statement.executeQuery();
			Integer available = bookingBean.getTruckId();
			boolean resultFlag = false;
			while (resultSet.next()) {
				Date date = Date.valueOf(bookingBean.getDateOfTransport());
				if (available.equals(resultSet.getInt("TRUCKID")) && resultSet.getInt("AVAILABLENOS") > 0) {

					statement = connection.prepareStatement(QueryMapper.insertQuery);

					statement.setString(1, bookingBean.getCustId());
					statement.setLong(2, bookingBean.getCustMobile());
					statement.setInt(3, bookingBean.getTruckId());
					statement.setInt(4, bookingBean.getNoOfTrucks());

					statement.setDate(5, date);
					// statement.setDate(5, bookingBean.getDateOfTransport());

					statement.executeUpdate();

					statement = connection.prepareStatement(QueryMapper.getId);
					ResultSet resultSet = statement.executeQuery();
					resultSet.next();
					bookId = resultSet.getInt(1);

					statement = connection.prepareStatement(QueryMapper.decrease);

					statement.setInt(1, bookingBean.getNoOfTrucks());
					statement.setInt(2, bookingBean.getTruckId());

					statement.executeUpdate();

					resultFlag = true;

				}

			}

			if (resultFlag == false) {
				System.err.println("no product found");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				System.err.println("statement not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection not created");
			}

		}

		return bookId;
	}

}
