package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TBSException;

public interface ITruckDao {

	List<TruckBean> truckAvailability(Integer truckID) throws TBSException;

	int bookDetails(BookingBean bookingBean) throws TBSException;

}
