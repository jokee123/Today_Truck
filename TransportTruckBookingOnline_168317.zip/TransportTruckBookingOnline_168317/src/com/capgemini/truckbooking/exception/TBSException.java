package com.capgemini.truckbooking.exception;

public class TBSException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1784496738434697430L;

	public TBSException(String message)

	{
		super(message);
	}
}
