package com.capgemini.truckbooking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.ITruckDaoImpl;

public class ITruckDaoImplTest {
ITruckDao dao=null;
	@Before
	public void setUp() throws Exception {
	dao=new ITruckDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	dao=null;
	}

	@Test
	public void testBookDetailsIsNotNull() {
		BookingBean bookingBean=new BookingBean();
		bookingBean.setCustId("Ab1234");
		bookingBean.setCustMobile(9789123421l);
bookingBean.setTruckId(1000);
bookingBean.setNoOfTrucks(2);


	}

}
